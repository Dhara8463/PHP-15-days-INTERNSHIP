<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '<T#V=*-WQ)-NU>LV1aI|-9P9=Pr0K{J&Ta_Mum4?w=U5Oz31?z2i~fKP9,;Rj+@i' );
define( 'SECURE_AUTH_KEY',  '}|VP`cKKQZxR38gfXGp}mU>`VUT,KYST}2pAPE{B|Y/xGsg.VU#G!D!6reDip#&6' );
define( 'LOGGED_IN_KEY',    'ZMkitggf xbhd$;Adra>ARLd,ufx_.m/.Fr)s!jjBl&f#+6.euW`cMGKOc$^yatN' );
define( 'NONCE_KEY',        '/0w%A.&Hl-VO?Cd0nY!!r_RUn rg1!`!]aZEUr;;d:Po$>V44B&UaS]X=rU;-t{{' );
define( 'AUTH_SALT',        '2?)xH+gB!yck!m]]l$/qW}H9m?h5E.?i>tKE#%UwlI-AV);KDC.{g#)s,!`VLH%O' );
define( 'SECURE_AUTH_SALT', 'P0qu!C/6~qHuhe0/S/N+Nt+o_E<&:23]]_zA/XG,5ko{d!#Xb3ljmUoQULbe j@;' );
define( 'LOGGED_IN_SALT',   'ejrL^}9NkLdCfE+o>{~a,F-6^w~PxS4X=KBv,`<*n(b<-wAuJDT_mxO23%_v!/s~' );
define( 'NONCE_SALT',       'PFgVjf49U5)YlUE^1Yz0%z0-of{zh(i[OYXb2L/P;u xRN,kx.:Qjt/$5=m*yMt}' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
